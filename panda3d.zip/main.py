import math
import time

from direct.showbase.ShowBase import ShowBase
from panda3d.core import KeyboardButton
from panda3d.core import AmbientLight
from direct.gui.OnscreenText import OnscreenText
from direct.actor.Actor import Actor
import random
from panda3d.core import TextNode

# Disable pylance for this one!

TORTURE = 50
SLOW = 2

dx = 0

bombs = []

score = 0

class App(ShowBase):
    def __init__(self):
        ShowBase.__init__(self)

        self.render.setShaderAuto()

        alight = AmbientLight("ambient")
        alight.setColor((1, 1, 1, 1))
        self.render.setLight(self.render.attachNewNode(alight))

        self.disableMouse()

        self.camera.setPos(0, 40, 10)
        self.camera.lookAt(0, 0, 10)

        self.panda = Actor(
            "chick.glb",
            {
                "walk": "chick.glb",
            }
        )

        bombs.append(self.loader.loadModel("bomb.glb"))
        bombs[0].reparentTo(self.render)
        bombs[0].setH(-90)
        bombs[0].setZ(50)

        self.panda.loop("walk")
        self.panda.setScale(30)
        self.panda.ls()
        self.panda.reparentTo(self.render)

        self.audio = self.loader.loadMusic('bomb.ogg')

        self.taskMgr.add(self.update, "update")
        self.taskMgr.add(self.update_input, "UpdateInputTask")

        self.text = OnscreenText(
            text="DIST",
            pos=(-1, 0.5),      # Position on screen
            scale=0.07,           # Size of the text
            fg=(1, 1, 1, 1),      # Font color (RGBA)
            align=TextNode.ALeft  # Alignment
        )

        self.panda.setH(180)

    def update(self, task):
        global score
        dt = globalClock.getDt()

        #self.panda.setH(self.panda.getH() + 50 * dt)
        for swas in bombs[:]:
            swas.setZ(swas.getZ() - 1/SLOW)

            if swas.getZ() < -3:
                self.audio.play()
                swas.removeNode()
                bombs.remove(swas)
                continue
            
            ere = self.panda.getDistance(swas)

            if ere <= 3.5:
                time.sleep(1)
                exit(0)
        
        if random.randint(0, TORTURE) == TORTURE:
            opo = self.loader.loadModel("bomb.glb")
            opo.reparentTo(self.render)
            opo.setH(-90)
            opo.setZ(50)
            opo.setX(random.uniform(-20, 20))
            
            print(opo.getX())
            bombs.append(opo)

        self.panda.setX(dx/3)
        self.text.text = f"Score: {score}"
        return task.cont

    def update_input(self, task):
        global dx
        # horizantal movement
        ope = base.mouseWatcherNode.is_button_down(KeyboardButton.ascii_key('a')) - base.mouseWatcherNode.is_button_down(KeyboardButton.ascii_key('d'))
        
        dx += ope
        #print(dx)
            
        return task.cont


app = App()
app.run()

#include <stdio.h>

int main() {
    printf("em works\n");
    return 0;
}
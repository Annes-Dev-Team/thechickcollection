#include "allegro5/altime.h"
#include "allegro5/bitmap.h"
#include "allegro5/bitmap_draw.h"
#include "allegro5/bitmap_io.h"
#include "allegro5/color.h"
#include "allegro5/display.h"
#include "allegro5/drawing.h"
#include "allegro5/keyboard.h"
#include "allegro5/keycodes.h"

#include <allegro5/allegro.h>
#include <allegro5/allegro_image.h>
#include <allegro5/allegro_primitives.h>

#include <allegro5/allegro_font.h>
#include <allegro5/allegro_ttf.h>

#include <allegro5/allegro_acodec.h>
#include <allegro5/allegro_audio.h>
#include <stdio.h>

#ifdef WEB
#include <emscripten.h>
#endif

#define WHITE al_map_rgb(255,255,255)
#define BLACK al_map_rgb(0,0,0)
#define RED al_map_rgb(255,0,0)
#define GREEN al_map_rgb(0,255,0)
#define BLUE al_map_rgb(0,0,255)

#define SPEED 10
#define BOMBS 10
#define BOMBSPEED 10
#define BOMBSIZE 2
int dx = 500;

typedef struct {
    int x;
    int y;
    int w;
    int h;
} Rectangle;

typedef struct {
    int x;
    int y;
    bool isinit;
} Bomb;

bool check_collision(Rectangle* rect1, Rectangle* rect2) {
    return (rect1->x < rect2->x + rect2->w &&
            rect1->x + rect1->w > rect2->x &&
            rect1->y < rect2->y + rect2->h &&
            rect1->y + rect1->h > rect2->y);
}

Rectangle get_chick_rect() {
    return (Rectangle){dx +20, 1000, 88, 128};
}

Rectangle get_bomb_rect(Bomb* bomb) {
    return (Rectangle){bomb->x + 50, bomb->y+60, (80) * BOMBSIZE, (80) * BOMBSIZE};
}

void draw_rect(Rectangle* rect, ALLEGRO_COLOR color) {
    al_draw_filled_rectangle(rect->x, rect->y, rect->x + rect->w, rect->y + rect->h, color);
}

Bomb bombs[BOMBS] = {0};
unsigned short score = 0;

ALLEGRO_DISPLAY *display;
ALLEGRO_EVENT_QUEUE *queue;
ALLEGRO_SAMPLE *bombsound;
ALLEGRO_KEYBOARD_STATE key_state;

ALLEGRO_BITMAP* chick ;
ALLEGRO_BITMAP* bombtex ;
ALLEGRO_FONT* font;
bool running;

void loop(void) {
        ALLEGRO_EVENT event;
        al_get_keyboard_state(&key_state);

        while (al_get_next_event(queue, &event)) {
            if (event.type == ALLEGRO_EVENT_DISPLAY_CLOSE)
                running = false;
        }

        if (al_key_down(&key_state, ALLEGRO_KEY_A)) {
            dx -= SPEED;
        }
        if (al_key_down(&key_state, ALLEGRO_KEY_D)) {
            dx += SPEED;
        }

        // Update
        // Draw
        if (dx < 0) {
            dx = 0;
        }
        if (dx > 1500) {
            dx = 1500;
        }

        al_clear_to_color(WHITE);
        Rectangle crect = get_chick_rect();
        draw_rect(&crect, GREEN);
        al_draw_bitmap(chick, dx, 1000, 0);
        for (int i = 0; i < BOMBS; i++) {
            Bomb* swas = &bombs[i];

            if (!swas->isinit) {
                if (rand() % 60 == 0) {
                    swas->isinit = true;
                    int rande = rand() % 1600;
                    swas->x = rande;
                    swas->y = 0;
                }
                continue;
            }

            if (swas->y > 1200) {
                swas->isinit = false;
                score++;
                #ifndef WEB
                al_play_sample(bombsound, 1, ((swas->x / 1600.0f) * 2.0f) - 1.0f, 1, ALLEGRO_PLAYMODE_ONCE, NULL);
                #endif
                continue;
            }
            
            Rectangle rect = get_bomb_rect(swas);
            if (check_collision(&crect, &rect)) {
                al_rest(1);
                exit(0);
            }
            draw_rect(&rect, RED);
            al_draw_scaled_bitmap(bombtex, 0,0,128,128,swas->x,swas->y,128*BOMBSIZE,128*BOMBSIZE,0);
            swas->y += 10;
        }
        al_draw_textf(font, BLUE, 0, 0, ALLEGRO_ALIGN_LEFT, "Score: %u", score);
        al_flip_display();

        al_rest(1.0 / 60.0);
}

int main() {
    printf("INIT\n");
    al_init();
    al_init_image_addon();

    al_init_font_addon();
    #ifndef WEB
    al_init_ttf_addon();
    #endif
    al_init_primitives_addon();

    al_install_keyboard();
    // I couldn't include audio when I built Allegro for web
    #ifndef WEB
    al_init_acodec_addon();
    al_install_audio();
    
    al_reserve_samples(15);
    #endif

    display = al_create_display(1600, 1200);
    printf("DISPLAY: %p\n", display);
    ALLEGRO_EVENT_QUEUE *queue = al_create_event_queue();
    printf("QUEUE: %p\n", queue);
    #ifndef WEB
    // Allegro doesnt really support MP3 for some reason
    bombsound = al_load_sample("bomb.ogg");
    printf("%p\n", bombsound);
    #endif

    al_register_event_source(queue, al_get_display_event_source(display));

    chick = al_load_bitmap("chick.png");
    bombtex = al_load_bitmap("bomb.png");

    #ifndef WEB
    font = al_load_ttf_font("fira.ttf", 50, 0);
    #else
    font = al_create_builtin_font();
    #endif

    running = true;

    #ifndef WEB
    while (running) {
        loop();
    }
    #else
    emscripten_set_main_loop(loop, 0, 1);
    #endif
    
    al_destroy_bitmap(chick);
    al_destroy_display(display);
    al_destroy_event_queue(queue);
    return 0;
}

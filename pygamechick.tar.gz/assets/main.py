import asyncio

import pygame,random

class Bomb:
    def __init__(self, x, y) -> None:
        self.x = x
        self.y = y

TORTURE = 10
SPEED = 5

score = 0

dx = 0

async def main():
    global dx,score
    pygame.init()
    pygame.mixer.init()
    pygame.font.init()
    screen = pygame.display.set_mode((800,600))
    pygame.display.set_caption("Bombs!")
    running = True

    bombs:list[Bomb] =[Bomb(0,0)]

    bombtex = pygame.image.load("bome.png").convert_alpha()
    chicktex = pygame.image.load("pychick.png").convert_alpha()
    boom = pygame.mixer.Sound('boom.ogg')

    font = pygame.font.SysFont(None, 50, True)

    pygame.display.set_icon(bombtex)

    clock = pygame.time.Clock()

    while running:
        dx = max(-30, min(dx, 750)) 
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                running = False
        
        keys = pygame.key.get_pressed()

        dx += (keys[pygame.K_d] - keys[pygame.K_a]) * 5

        screen.fill("white")

        if random.randint(0, TORTURE) == TORTURE:
            bombs.append(Bomb(random.randint(0, 800), - 100))

        crect = pygame.Rect(dx + 30, 510, 28, 30)
        #pygame.draw.rect(screen, "green", crect)
        screen.blit(chicktex, (dx, 490))

        for swas in bombs[:]:

            rect = pygame.Rect(swas.x+20, swas.y+20, 28, 38)
            #pygame.draw.rect(screen, "red", rect)

            if rect.colliderect(crect):
                await asyncio.sleep(1)
                pygame.quit()
                return

            screen.blit(bombtex, (swas.x, swas.y))
            swas.y += SPEED

            if swas.y > 600:
                boom.play()
                score+=1
                bombs.remove(swas)

            screen.blit(font.render(f"Score: {score}", False, 'blue', None), (0,0))

        pygame.display.flip()
        clock.tick(60)
        await asyncio.sleep(0)

    pygame.quit()

if __name__ == "__main__":
    asyncio.run(main())

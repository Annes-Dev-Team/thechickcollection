-- Returns true if two rectangles overlap, false if they do not
local function checkCollision(x1, y1, w1, h1, x2, y2, w2, h2)
    return x1 < x2 + w2 and
           x2 < x1 + w1 and
           y1 < y2 + h2 and
           y2 < y1 + h1
end

local speaker = peripheral.find("speaker")

local chickimg = paintutils.loadImage('chick.nfp')
local bombimg = paintutils.loadImage('bomb.nfp')

-- widths and heights of chick and bomb
local chickdim = {9, 11} -- wow.
local bombdim = {8, 4}

local score = 0
local playerx = 25

local playerdir = 0 -- 1 = right, -1 = left

-- one bomb per thingy
local bombx = 1
local bomby = -11

local function main()
    local tick = os.startTimer(1/30)
    while true do
        local event,key = os.pullEvent()

        if event == "key" then
            if key == keys.right then
                playerdir = 2
            end
            if key == keys.left then
                playerdir = -2
            end
        end
        if event == "key_up" then
            if key == keys.left or key == keys.right then
                playerdir = 0
            end
        end

        -- main loop
        if event == "timer" and key == tick then
            local w,h = term.getSize()

            bomby = bomby + 0.7

            if bomby > 25 then
                bomby = -11
                bombx = math.random(1, w - 7)
                score = score + 1
                if speaker then
                    speaker.playNote("hat", 1, 5)
                end
            end

            playerx = playerx + playerdir

            if playerx < 1 then
                playerx = 1
            end
            if playerx > w - 8 then
                playerx = w - 8
            end

            if checkCollision(playerx, h - 11, chickdim[1], chickdim[2], bombx, bomby + 3, bombdim[1], bombdim[2]) then
                if speaker then
                    speaker.playNote("hat", 1, 0)
                    os.sleep(0.1)
                    speaker.playNote("hat", 1, 0)
                    os.sleep(0.1)
                    speaker.playNote("hat", 1, 0)
                end
                os.sleep(1)
                error("Frick, you lost", 0)
            end

            term.setBackgroundColor(colors.white)
            term.clear()

            paintutils.drawImage(chickimg, playerx, h - 11)
            paintutils.drawImage(bombimg, bombx, bomby)

            term.setCursorPos(1, 1)
            term.write(("Score: %d"):format(score))

            tick = os.startTimer(1/30)
        end
    end
end

main()
